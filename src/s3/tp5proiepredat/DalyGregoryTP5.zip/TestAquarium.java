package s3.tp5proiepredat;

public class TestAquarium {

    public static void main(String[] args) {
        Aquarium A = new Aquarium(400, 24);
        A.simulation(1000);

    }

}
